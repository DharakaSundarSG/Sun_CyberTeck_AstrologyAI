import streamlit as st
import ollama
from datetime import date, datetime


# ============================================================
# CONFIG
# ============================================================

st.set_page_config(
    page_title="SunCyberTek Astrology AI",
    page_icon="🔮",
    layout="centered"
)

MODEL = "gemma3:1b"


# ============================================================
# SESSION STATE
# ============================================================

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []


# ============================================================
# TITLE
# ============================================================

st.title("🔮 SunCyberTek Astrology AI")
st.caption("Vedic Astrology Assistant powered by Ollama")


# ============================================================
# SIDEBAR
# ============================================================

with st.sidebar:

    st.header("🌟 Birth Details")

    name = st.text_input(
        "Name",
        placeholder="Enter your name"
    )

    dob = st.date_input(
        "Date of Birth",
        value=date(2000, 1, 1),
        min_value=date(1900, 1, 1),
        max_value=date.today()
    )

    # Default = 11:25 AM
    birth_time = st.time_input(
        "Time of Birth",
        value=datetime.strptime(
            "11:25",
            "%H:%M"
        ).time()
    )

    birthplace = st.text_input(
        "Place of Birth",
        placeholder="Example: Chennai, Tamil Nadu, India"
    )

    language = st.selectbox(
        "Response Language",
        [
            "English",
            "Tamil",
            "Hindi"
        ]
    )

    generate = st.button(
        "🔮 Generate Astrology Reading",
        use_container_width=True
    )

    clear_chat = st.button(
        "🗑️ Clear Questions",
        use_container_width=True
    )

    if clear_chat:
        st.session_state.chat_history = []
        st.rerun()


# ============================================================
# VALIDATION
# ============================================================

if not name or not birthplace:

    st.info(
        "👈 Enter your name and birth place in the sidebar "
        "to start your astrology reading."
    )


# ============================================================
# GENERATE ASTROLOGY READING
# ============================================================

if generate:

    if not name:

        st.warning(
            "⚠️ Please enter your name."
        )

    elif not birthplace:

        st.warning(
            "⚠️ Please enter your place of birth."
        )

    else:

        st.subheader(
            "🔮 Your Astrology Reading"
        )

        col1, col2 = st.columns(2)

        with col1:

            st.write(
                f"**Name:** {name}"
            )

            st.write(
                f"**Date:** {dob}"
            )

        with col2:

            st.write(
                f"**Time:** {birth_time.strftime('%I:%M %p')}"
            )

            st.write(
                f"**Place:** {birthplace}"
            )

        st.divider()

        prompt = f"""
You are SunCyberTek Astrology AI.

Give a traditional Vedic astrology style interpretation.

PERSON DETAILS:

Name: {name}
Date of Birth: {dob}
Time of Birth: {birth_time.strftime('%I:%M %p')}
Place of Birth: {birthplace}

Language: {language}

IMPORTANT:

- Do not claim scientific certainty.
- Do not invent planetary positions.
- Do not present predictions as guaranteed events.
- Keep the explanation simple.
- Do not reveal private chain-of-thought.

Explain:

1. 🌟 Personality
2. 🌙 Emotional Nature
3. 💼 Career
4. 💰 Finance
5. ❤️ Love
6. 💍 Marriage
7. 📚 Education
8. 👨‍👩‍👧 Family
9. ✈️ Foreign Travel
10. 💪 Strengths
11. ⚠️ Areas to Improve
12. 🔮 General Future Themes
13. 🍀 Traditional Lucky Suggestions

Answer in {language}.
"""

        response_box = st.empty()

        full_response = ""

        try:

            response = ollama.chat(
                model=MODEL,
                messages=[
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                stream=True
            )

            for chunk in response:

                text = (
                    chunk
                    .get("message", {})
                    .get("content", "")
                )

                if text:

                    full_response += text

                    response_box.markdown(
                        full_response + "▌"
                    )

            response_box.markdown(
                full_response
            )

        except Exception as e:

            st.error(
                f"Ollama Error: {e}"
            )


# ============================================================
# ASK ASTROLOGY QUESTIONS
# ============================================================

st.divider()

st.subheader("💬 Ask SunCyberTek")

st.caption(
    "Ask a question about your career, love, marriage, "
    "finance, education, family or general astrology."
)


# ============================================================
# SHOW PREVIOUS QUESTIONS
# ============================================================

for chat in st.session_state.chat_history:

    with st.chat_message("user"):

        st.markdown(
            chat["question"]
        )

    with st.chat_message("assistant"):

        st.markdown(
            chat["answer"]
        )


# ============================================================
# QUESTION INPUT
# ============================================================

question = st.chat_input(
    "Ask your astrology question..."
)


# ============================================================
# PROCESS QUESTION
# ============================================================

if question:

    if not name or not birthplace:

        st.warning(
            "⚠️ Please enter your Name and Place of Birth "
            "in the sidebar first."
        )

    else:

        with st.chat_message("user"):

            st.markdown(question)

        astrology_prompt = f"""
You are SunCyberTek Astrology AI.

The user wants a traditional Vedic astrology style
interpretation.

USER DETAILS
--------------------------------

Name:
{name}

Date of Birth:
{dob}

Time of Birth:
{birth_time.strftime('%I:%M %p')}

Place of Birth:
{birthplace}

LANGUAGE:
{language}

USER QUESTION:
{question}

INSTRUCTIONS
--------------------------------

- Answer the user's exact question.
- Keep the answer simple and clear.
- Use traditional astrology concepts where appropriate.
- Do not invent planetary positions.
- Do not claim scientific certainty.
- Do not present future events as guaranteed.
- Do not reveal private chain-of-thought.
- If the question cannot be answered from the supplied
  information, clearly say what additional information
  would be required.
- Answer in {language}.
"""

        with st.chat_message("assistant"):

            response_box = st.empty()

            answer = ""

            try:

                response = ollama.chat(
                    model=MODEL,
                    messages=[
                        {
                            "role": "user",
                            "content": astrology_prompt
                        }
                    ],
                    stream=True
                )

                for chunk in response:

                    text = (
                        chunk
                        .get("message", {})
                        .get("content", "")
                    )

                    if text:

                        answer += text

                        response_box.markdown(
                            answer + "▌"
                        )

                response_box.markdown(
                    answer
                )

                # Save conversation

                st.session_state.chat_history.append(
                    {
                        "question": question,
                        "answer": answer
                    }
                )

            except Exception as e:

                response_box.error(
                    f"❌ Ollama Error: {e}"
                )


# ============================================================
# FOOTER
# ============================================================

st.divider()

st.caption(
    "✦ SunCyberTek Astrology AI • Powered by Ollama"
)

st.caption(
    "Traditional astrology interpretation only; "
    "not scientifically validated prediction."
)